const cartItems = JSON.parse(localStorage.getItem('cartItems'));
// Hiển thị thông tin các sản phẩm trong giỏ hàng
if (cartItems && cartItems.length > 0) {
    const cartContainer = document.getElementById('cart-items');

    cartItems.forEach((item, index) => {
        // Tạo thẻ div card cho mỗi sản phẩm
        const productCard = document.createElement('div');
        productCard.classList.add('col-md-4', 'mb-3', 'card');

        const productImage = document.createElement('img');
        productImage.src = item.productImage;
        productImage.alt = item.productName;
        productImage.classList.add('card-img-top');
        productCard.appendChild(productImage);

        // Tạo thẻ div chứa thông tin sản phẩm
        const productCardBody = document.createElement('div');
        productCardBody.classList.add('card-body');

        const productName = document.createElement('h5');
        productName.classList.add('card-title');
        productName.textContent = item.productName;
        productCardBody.appendChild(productName);

        const productType = document.createElement('p');
        productType.classList.add('card-text');
        productType.textContent = `Loại: ${item.productType}`;
        productCardBody.appendChild(productType);

        const productPrice = document.createElement('p');
        productPrice.classList.add('card-text');
        productPrice.textContent = `Giá: ${item.productPrice}`;
        productCardBody.appendChild(productPrice);

        // Nút Xóa
        const deleteButton = document.createElement('button');
        deleteButton.classList.add('btn', 'btn-danger', 'btn-delete');
        deleteButton.setAttribute('data-index', index);
        deleteButton.textContent = 'Xóa';
        productCardBody.appendChild(deleteButton);

        // Thêm thẻ div chứa thông tin sản phẩm vào thẻ card
        productCard.appendChild(productCardBody);

        // Thêm thẻ card vào giỏ hàng
        cartContainer.appendChild(productCard);
    });

    // Xử lý sự kiện khi người dùng nhấn nút xóa
    cartContainer.addEventListener('click', function (event) {
        if (event.target.classList.contains('btn-delete')) {
            const index = event.target.getAttribute('data-index');
            // Xóa sản phẩm khỏi danh sách giỏ hàng
            cartItems.splice(index, 1);
            // Lưu danh sách sản phẩm mới vào localStorage
            localStorage.setItem('cartItems', JSON.stringify(cartItems));
            // Xóa thẻ card khỏi giao diện
            event.target.closest('.col-md-4').remove();
        }
    });
} else {
    // Hiển thị thông báo nếu không có sản phẩm nào trong giỏ hàng
    document.getElementById('cart-items').innerHTML = '<p>Không có sản phẩm trong giỏ hàng</p>';
}
