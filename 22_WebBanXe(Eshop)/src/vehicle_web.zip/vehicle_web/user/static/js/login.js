function toggle() {
    const loginForm = document.getElementById('login-form');
    loginForm.classList.toggle('sign-in');
    loginForm.classList.toggle('sign-up');
}

// $(document).ready(function() {
//     $('#signup-button').click(function() {
//         var username = $('#username').val();
//         var email = $('#email').val();
//         var password = $('#password').val();
//         var confirmPassword = $('#confirmPassword').val();

//         if (password !== confirmPassword) {
//             alert('Passwords do not match');
//             return;
//         }

//         $.ajax({
//             type: 'POST',
//             url: '/user/api/register/',  // Đảm bảo URL này khớp với đường dẫn đã định nghĩa trong urls.py của app user
//             data: JSON.stringify({
//                 username: username,
//                 email: email,
//                 password: password
//             }),
//             contentType: 'application/json',
//             success: function(response) {
//                 alert('User registered successfully!');
//                 toggle(); // Chuyển đổi sang form đăng nhập
//             },
//             error: function(xhr, status, error) {
//                 var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : 'An error occurred';
//                 alert(errorMessage);
//             }
//         });
//     });

//     $('#login-button').click(function() {
//         var email = $('#login-email').val();
//         var password = $('#login-password').val();

//         $.ajax({
//             type: 'POST',
//             url: '/user/api/login/',  // Đảm bảo URL này khớp với đường dẫn đã định nghĩa trong urls.py của app user
//             data: JSON.stringify({
//                 email: email,
//                 password: password
//             }),
//             contentType: 'application/json',
//             success: function(response) {
//                 alert('User logged in successfully!');
//                 // Xử lý thành công đăng nhập
//                 window.location.href = '';
//             },
//             error: function(xhr, status, error) {
//                 var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : 'An error occurred';
//                 alert(errorMessage);
//                 window.location.href = '/login/';
//             }
//         });
//     });
// });

const signupButton = document.getElementById('signup-button');

signupButton.addEventListener('click', async () => {
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    if (password !== confirmPassword) {
        alert('Passwords do not match');
        return;
    }

    const response = await fetch('/user/signup/', {  // Đường dẫn phải là '/user/api/signup/'
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            username,
            email,
            password
        })
    });

    if (response.ok) {
        const data = await response.json();
        alert('User registered successfully!');
        window.location.href = '';  // Chuyển hướng về trang chủ sau khi đăng ký thành công
    } else {
        const errorData = await response.json();
        var errorMessage = errorData.message || 'An error occurred';
        alert(errorMessage);
        window.location.href = '/login/';  // Chuyển hướng về trang đăng nhập nếu có lỗi
    }
});
