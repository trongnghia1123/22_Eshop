from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm

from .models import * 

def login_page(request):
    context = {}
    return  render(request, 'user/login.html', context)

# class SignUpView(APIView):
#     def post(self, request):
#         serializer = SignUpSerializer(data=request.data)
#         serializer.is_valid(raise_exception=True)
#         serializer.save()  # Creates the user object with validated data
#         user = authenticate(email=request.data['email'], password=request.data['password'])
#         if user is not None:
#             login(request, user)
#             return Response({'message': 'Registration successful!'}, status=status.HTTP_201_CREATED)
#         else:
#             return Response({'error': 'Authentication failed'}, status=status.HTTP_401_UNAUTHORIZED)

# class LoginAPIView(APIView):
#     def post(self, request):
#         email = request.data.get('email')
#         password = request.data.get('password')

#         user = authenticate(email=email, password=password)
#         if user:
#             refresh = RefreshToken.for_user(user)
#             return Response({
#                 'message': 'Đăng nhập thành công',
#                 'refresh': str(refresh),
#                 'access': str(refresh.access_token),
#             }, status=status.HTTP_200_OK)
#         return Response({'message': 'Sai thông tin đăng nhập'}, status=status.HTTP_400_BAD_REQUEST)
